<?php
/* @var $this yii\web\View */
$this->title = 'My Yii Application';
?>

The latest version of Yii 2 is 2.0.5, released on July 11, 2015. Yii 2.0 is a complete rewrite of Yii on top of PHP 5.4.0. It is aimed to become a state-of-the-art of the new generation of PHP framework. Yii 2.0 is not compatible with 1.1.